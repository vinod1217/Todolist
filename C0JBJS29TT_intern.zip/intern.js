// Tab switching
const tabs = document.querySelectorAll(".tab");
const contents = document.querySelectorAll(".tab-content");

tabs.forEach(tab => {
    tab.addEventListener("click", () => {
        tabs.forEach(t => t.classList.remove("active"));
        contents.forEach(c => c.classList.add("hidden"));
        tab.classList.add("active");
        document.getElementById(tab.dataset.tab).classList.remove("hidden");
    });
});

// Gallery add image
const fileInput = document.getElementById("fileInput");
const addBtn = document.getElementById("addImageBtn");
const gallery = document.getElementById("gallery");

addBtn.addEventListener("click", () => fileInput.click());

fileInput.addEventListener("change", e => {
    const file = e.target.files[0];
    if (file) {
        const img = document.createElement("img");
        img.src = URL.createObjectURL(file);
        img.style.filter = "brightness(0.5)";
        img.addEventListener("mouseenter", () => img.style.filter = "brightness(1)");
        img.addEventListener("mouseleave", () => img.style.filter = "brightness(0.5)");
        gallery.appendChild(img);
    }
});

// Gallery navigation
let currentIndex = 0;
const visibleCount = 3;

function updateGallery() {
    const images = gallery.children;
    for (let i = 0; i < images.length; i++) {
        images[i].style.display = (i >= currentIndex && i < currentIndex + visibleCount) ?
            "block" : "none";
    }
}
updateGallery();

document.querySelector(".arrow.right").addEventListener("click", () => {
    const total = gallery.children.length;
    if (currentIndex + visibleCount < total) {
        currentIndex += visibleCount;
        updateGallery();
    }
});

document.querySelector(".arrow.left").addEventListener("click", () => {
    if (currentIndex - visibleCount >= 0) {
        currentIndex -= visibleCount;
        updateGallery();
    }
});